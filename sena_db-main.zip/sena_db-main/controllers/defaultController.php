<?php

class DefaultController
{
    public function index()
    {
        require_once "views/layouts/sidebar.php";
    }
}
