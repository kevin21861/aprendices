<?php
define("base_url", "http://localhost/sena_db-main/");
// define("base_url", "/");
define("controller_default","aprendizController");
define("action_default","verAprendices");
